import slider from "./component/slider.js";

document.addEventListener('DOMContentLoaded', () => {
    slider();
});